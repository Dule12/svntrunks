#!/usr/bin/env bash

DEFAULT_JAVABIN=${TEST_SRCDIR}/__main__/../remotejdk11_linux/bin/java
JAVA_EXEC_TO_USE=${REAL_EXTERNAL_JAVA_BIN:-$DEFAULT_JAVABIN}
exec $JAVA_EXEC_TO_USE "$@" 
